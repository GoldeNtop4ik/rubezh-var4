﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_21._102_Scherbakov_4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string predl = tbIN.Text;
                if (string.IsNullOrWhiteSpace(predl))
                {
                    throw new Exception("Пожалуйста, введите строку.");
                }
                string[] words = predl.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if(words.Length == 0)
                {
                    throw new Exception("Пожалуйста, введите строку с содержимым.");
                }
                string result = "";
                foreach (string word in words)
                {
                    string slova = word.Substring(0, 1).ToUpper() + word.Substring(1, word.Length - 2) + word.Substring(word.Length - 1).ToUpper();
                    result += slova + " ";
                }

                result = result.TrimEnd().Replace(" ", "это_пробел");

                tbOut.Text = result;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }


        }
    }
}
